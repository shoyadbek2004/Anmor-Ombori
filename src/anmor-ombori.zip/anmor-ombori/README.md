# FastFood Ombori — Netlify'ga joylashtirish

## Loyihada nima bor
- `src/App.jsx` — asosiy dastur (tuzatilgan, vaqtga asoslangan "kunlar qoldi" hisobi bilan)
- `localStorage` — ma'lumotlar endi brauzerda real saqlanadi
- `netlify/functions/ai-assistant.js` — AI Yordamchi endi shu orqali ishlaydi, API key faqat serverda turadi, brauzerga chiqmaydi

## 1-qadam: Anthropic API key olish
1. https://console.anthropic.com ga kiring (ro'yxatdan o'ting/kiring)
2. **API Keys** bo'limidan yangi key yarating va nusxalab oling (`sk-ant-...`)
3. Bu hisobda balans/limit borligiga ishonch hosil qiling — AI Yordamchi har so'rovda shu hisobdan pul yechadi

## 2-qadam: Loyihani GitHub'ga yuklash
1. https://github.com da yangi **repository** yarating (masalan: `anmor-ombori`)
2. "uploading an existing file" havolasi orqali shu papkadagi barcha fayl va papkalarni (papka tuzilishini saqlab) yuklang
3. Commit qiling

> Eslatma: `node_modules` va `dist` papkalarini yuklamang — ular kerak emas, Netlify o'zi yaratadi (`.gitignore` da shu yozilgan).

## 3-qadam: Netlify'ga ulash
1. https://app.netlify.com → **Add new site** → **Import an existing project**
2. GitHub'ni tanlang, yuqoridagi repo'ni tanlang
3. Build sozlamalari `netlify.toml` dan avtomatik olinadi (build: `npm run build`, publish: `dist`) — shunchaki **Deploy** bosing

## 4-qadam: API key'ni Netlify'ga qo'shish
1. Netlify saytida: **Site configuration → Environment variables → Add a variable**
2. Key: `ANTHROPIC_API_KEY`, Value: 2-qadamda olgan key
3. Saqlang, so'ng **Deploys → Trigger deploy → Deploy site** bosing (key qo'shilgandan keyin qayta deploy kerak)

## Tayyor!
Saytga kirib, AI Yordamchini sinab ko'ring. Agar xato chiqsa, Netlify'dagi **Functions** bo'limidan `ai-assistant` logini ochib sababini ko'rish mumkin.

## Eslatma — xavfsizlik
API key hech qachon kodga yoki GitHub'ga yozilmasin (faqat Netlify Environment variables ichida tursin). Aks holda boshqalar uni ko'rib, sizning hisobingizdan foydalanib qo'yishi mumkin.
